public class Main {
    public static void main(String[] args) {
        SinglyLinklist<String> a=new SinglyLinklist<>();
        a.addfrist("abduuuu");
        a.addfrist("almagnooon");
        a.addliast("Bkhash");
        a.addfrist("ENG");
      //  System.out.println(a.print());

       // System.out.println(a.uSershScand());
//        System.out.println(a.print());
//        a.rotat();
       // System.out.println(a.print());


        SinglyLinklist<String> b=new SinglyLinklist<>();
        b.addfrist("waled");
        b.addfrist("ebrihe,");
        b.addfrist("korde");
        b.addfrist("soleman");

//
       SinglyLinklist<String> c=new SinglyLinklist<>();
//
           //     c.Merge(b);
        System.out.println(c.print());
     //   System.out.println(b.print());
      //  b.finding();
    }
}
