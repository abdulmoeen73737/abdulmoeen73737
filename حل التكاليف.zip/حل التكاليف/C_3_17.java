public class C_3_17 {
    static int[] a={1,2,3,4,5,6,7,8,4};
    static public void run(){
        for (int i = 0; i < a.length; i++) {
           if (a[i]%2==0){
               System.out.println(a[i]);
           }

        }
    }
    public static void main(String[] args) {
run();
    }
}
